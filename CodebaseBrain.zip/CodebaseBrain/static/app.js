const API_BASE = '';

let currentSessionId = generateSessionId();

function generateSessionId() {
    return 'session_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9);
}

async function updateStats() {
    try {
        const response = await fetch(`${API_BASE}/stats`);
        const data = await response.json();
        document.getElementById('chunksCount').textContent = `Chunks: ${data.indexed_chunks}`;
        document.getElementById('sessionsCount').textContent = `Sessions: ${data.active_sessions}`;
    } catch (error) {
        console.error('Error updating stats:', error);
    }
}

function showStatus(elementId, message, isSuccess) {
    const element = document.getElementById(elementId);
    element.textContent = message;
    element.className = 'status-message ' + (isSuccess ? 'success' : 'error');
    element.style.display = 'block';
    
    setTimeout(() => {
        element.style.display = 'none';
    }, 5000);
}

document.getElementById('indexBtn').addEventListener('click', async () => {
    const path = document.getElementById('indexPath').value || '.';
    const extensionsInput = document.getElementById('indexExtensions').value;
    const extensions = extensionsInput.split(',').map(ext => ext.trim());
    
    const btn = document.getElementById('indexBtn');
    btn.disabled = true;
    btn.textContent = 'Indexing...';
    
    try {
        const response = await fetch(`${API_BASE}/index`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ path, extensions })
        });
        
        const data = await response.json();
        
        if (response.ok) {
            showStatus('indexStatus', 
                `Success! Indexed ${data.files_indexed} files into ${data.total_chunks} chunks.`, 
                true);
            updateStats();
        } else {
            showStatus('indexStatus', `Error: ${data.detail || 'Failed to index'}`, false);
        }
    } catch (error) {
        showStatus('indexStatus', `Error: ${error.message}`, false);
    } finally {
        btn.disabled = false;
        btn.textContent = 'Index Codebase';
    }
});

document.getElementById('queryBtn').addEventListener('click', async () => {
    const question = document.getElementById('queryInput').value.trim();
    const topK = parseInt(document.getElementById('queryTopK').value) || 5;
    
    if (!question) {
        alert('Please enter a question');
        return;
    }
    
    const btn = document.getElementById('queryBtn');
    const loading = document.getElementById('queryLoading');
    const responseArea = document.getElementById('queryResponse');
    
    btn.disabled = true;
    loading.style.display = 'block';
    responseArea.innerHTML = '';
    
    try {
        const response = await fetch(`${API_BASE}/query`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ question, top_k: topK })
        });
        
        const data = await response.json();
        
        if (response.ok) {
            displayQueryResponse(data);
        } else {
            responseArea.innerHTML = `<div class="answer error"><strong>Error:</strong> ${data.detail}</div>`;
        }
    } catch (error) {
        responseArea.innerHTML = `<div class="answer error"><strong>Error:</strong> ${error.message}</div>`;
    } finally {
        btn.disabled = false;
        loading.style.display = 'none';
    }
});

function displayQueryResponse(data) {
    const responseArea = document.getElementById('queryResponse');
    
    let html = `
        <div class="answer">
            <h3>Answer</h3>
            ${formatMarkdown(data.answer)}
        </div>
    `;
    
    if (data.context && data.context.length > 0) {
        html += '<h3 style="margin: 20px 0 10px 0; color: #667eea;">Retrieved Code Context</h3>';
        html += '<div class="context-chunks">';
        
        data.context.forEach((chunk, index) => {
            html += `
                <div class="context-chunk">
                    <div class="chunk-header">
                        <span class="chunk-file">${escapeHtml(chunk.file_path)}</span>
                        <span class="chunk-lines">Lines ${chunk.start_line}-${chunk.end_line}</span>
                    </div>
                    <div class="chunk-content">${escapeHtml(chunk.content)}</div>
                </div>
            `;
        });
        
        html += '</div>';
    }
    
    responseArea.innerHTML = html;
}

document.getElementById('sessionId').value = currentSessionId;

document.getElementById('newSessionBtn').addEventListener('click', () => {
    currentSessionId = generateSessionId();
    document.getElementById('sessionId').value = currentSessionId;
    document.getElementById('chatMessages').innerHTML = '<div class="empty-state">New session started. Ask a question to begin.</div>';
});

document.getElementById('clearSessionBtn').addEventListener('click', async () => {
    try {
        await fetch(`${API_BASE}/sessions/${currentSessionId}`, {
            method: 'DELETE'
        });
        document.getElementById('chatMessages').innerHTML = '<div class="empty-state">Session cleared.</div>';
        updateStats();
    } catch (error) {
        console.error('Error clearing session:', error);
    }
});

document.getElementById('chatSendBtn').addEventListener('click', sendChatMessage);

document.getElementById('chatInput').addEventListener('keydown', (e) => {
    if (e.key === 'Enter' && e.ctrlKey) {
        sendChatMessage();
    }
});

async function sendChatMessage() {
    const message = document.getElementById('chatInput').value.trim();
    const topK = 5;
    
    if (!message) {
        alert('Please enter a message');
        return;
    }
    
    const btn = document.getElementById('chatSendBtn');
    const messagesArea = document.getElementById('chatMessages');
    
    if (messagesArea.querySelector('.empty-state')) {
        messagesArea.innerHTML = '';
    }
    
    addChatMessage('user', message);
    
    document.getElementById('chatInput').value = '';
    btn.disabled = true;
    btn.textContent = 'Analyzing...';
    
    try {
        const response = await fetch(`${API_BASE}/chat`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ 
                session_id: currentSessionId, 
                message, 
                top_k: topK 
            })
        });
        
        const data = await response.json();
        
        if (response.ok) {
            addChatMessage('assistant', data.answer, data.context);
            updateStats();
        } else {
            addChatMessage('assistant', `Error: ${data.detail}`, []);
        }
    } catch (error) {
        addChatMessage('assistant', `Error: ${error.message}`, []);
    } finally {
        btn.disabled = false;
        btn.textContent = 'Send';
    }
}

function addChatMessage(role, content, context = null) {
    const messagesArea = document.getElementById('chatMessages');
    
    const messageDiv = document.createElement('div');
    messageDiv.className = `chat-message ${role}`;
    
    let contextHtml = '';
    if (context && context.length > 0) {
        contextHtml = '<div style="margin-top: 10px; padding-top: 10px; border-top: 1px solid rgba(0,0,0,0.1);">';
        contextHtml += '<div style="font-size: 0.85em; color: #666; margin-bottom: 5px;">Context:</div>';
        context.forEach(chunk => {
            contextHtml += `<div style="font-size: 0.8em; color: #888; margin-bottom: 3px;">${escapeHtml(chunk.file_path)} (${chunk.start_line}-${chunk.end_line})</div>`;
        });
        contextHtml += '</div>';
    }
    
    messageDiv.innerHTML = `
        <div class="message-label">${role === 'user' ? 'You' : 'Assistant'}</div>
        <div class="message-content">
            ${formatMarkdown(content)}
            ${contextHtml}
        </div>
    `;
    
    messagesArea.appendChild(messageDiv);
    messagesArea.scrollTop = messagesArea.scrollHeight;
}

function formatMarkdown(text) {
    let html = escapeHtml(text);
    
    html = html.replace(/```(\w+)?\n([\s\S]*?)```/g, (match, lang, code) => {
        return `<pre><code>${code.trim()}</code></pre>`;
    });
    
    html = html.replace(/`([^`]+)`/g, '<code>$1</code>');
    
    html = html.replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>');
    html = html.replace(/\*(.+?)\*/g, '<em>$1</em>');
    
    html = html.replace(/\n\n/g, '<br><br>');
    html = html.replace(/\n/g, '<br>');
    
    return html;
}

function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

updateStats();
setInterval(updateStats, 10000);

document.getElementById('chatMessages').innerHTML = '<div class="empty-state">Start a conversation by sending a message below.</div>';
