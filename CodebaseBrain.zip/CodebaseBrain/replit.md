# AI Coding Assistant

## Overview
A full-stack AI-powered coding assistant built with FastAPI backend and vanilla HTML/CSS/JS frontend. The application indexes codebases, generates embeddings using OpenAI, and provides context-aware debugging assistance through one-shot queries and multi-turn chat conversations.

## Project Architecture

### Backend (FastAPI)
- **main.py**: Core FastAPI application with the following endpoints:
  - `POST /index`: Index codebase files and generate embeddings
  - `POST /query`: One-shot question answering with context retrieval
  - `POST /chat`: Multi-turn conversational debugging assistant
  - `GET /sessions/{session_id}/history`: Retrieve chat history
  - `DELETE /sessions/{session_id}`: Clear chat session
  - `GET /stats`: Get indexing and session statistics

### Frontend (HTML/CSS/JS)
- **static/index.html**: Main UI with three panels (indexing, query, chat)
- **static/styles.css**: Modern gradient-based styling with responsive design
- **static/app.js**: Client-side logic for API interactions

## Key Features
1. **Code Indexing**: Chunks files into 50-line segments with OpenAI embeddings
2. **Semantic Search**: Uses cosine similarity to retrieve relevant code chunks
3. **One-Shot Queries**: Direct Q&A with context-aware responses
4. **Multi-Turn Chat**: Persistent debugging conversations with history
5. **Context Display**: Shows file names, line ranges, and code snippets used

## Dependencies
- fastapi: Web framework
- uvicorn: ASGI server
- openai: OpenAI API client
- numpy: Numerical operations
- scikit-learn: Cosine similarity calculations
- python-multipart: File upload support

## Configuration
- Server runs on port 5000
- Binds to 0.0.0.0 for Replit compatibility
- Uses OpenAI's text-embedding-3-small for embeddings
- Uses GPT-4o-mini for chat completions

## Recent Changes
- 2025-11-20: Initial project setup with complete backend and frontend implementation
- OpenAI integration configured via Replit integration system
- Excluded common directories (node_modules, .git, __pycache__, venv, dist, build) from indexing

## User Preferences
- Focus on accurate, context-aware debugging
- Provide concrete fixes with file names and line ranges
- No mock data - all responses use real OpenAI API
