from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse
from pydantic import BaseModel
from typing import List, Optional, Dict
import os
import json
import numpy as np
from pathlib import Path
from openai import OpenAI
from sklearn.metrics.pairwise import cosine_similarity

app = FastAPI(title="AI Coding Assistant")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

_client = None

def get_openai_client():
    global _client
    if _client is None:
        api_key = os.getenv("OPENAI_API_KEY")
        if not api_key:
            raise HTTPException(
                status_code=500,
                detail="OpenAI API key not configured. Please add OPENAI_API_KEY to your secrets."
            )
        _client = OpenAI(api_key=api_key)
    return _client

code_chunks = []
embeddings = []
chat_sessions = {}

class IndexRequest(BaseModel):
    path: str = "."
    extensions: List[str] = [".py", ".js", ".ts", ".jsx", ".tsx", ".html", ".css", ".json"]
    max_chunk_size: int = 500

class QueryRequest(BaseModel):
    question: str
    top_k: int = 5

class ChatRequest(BaseModel):
    session_id: str
    message: str
    top_k: int = 5

class CodeChunk(BaseModel):
    file_path: str
    content: str
    start_line: int
    end_line: int
    embedding: Optional[List[float]] = None

def chunk_file(file_path: str, max_lines: int = 50) -> List[Dict]:
    chunks = []
    try:
        with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
            lines = f.readlines()
        
        total_lines = len(lines)
        for i in range(0, total_lines, max_lines):
            chunk_lines = lines[i:i + max_lines]
            chunk_content = ''.join(chunk_lines)
            
            if chunk_content.strip():
                chunks.append({
                    "file_path": file_path,
                    "content": chunk_content,
                    "start_line": i + 1,
                    "end_line": min(i + max_lines, total_lines)
                })
    except Exception as e:
        print(f"Error reading {file_path}: {e}")
    
    return chunks

def get_embedding(text: str) -> List[float]:
    try:
        client = get_openai_client()
        response = client.embeddings.create(
            input=text,
            model="text-embedding-3-small"
        )
        return response.data[0].embedding
    except Exception as e:
        print(f"Error getting embedding: {e}")
        return []

def retrieve_relevant_chunks(query: str, top_k: int = 5) -> List[Dict]:
    if not code_chunks or not embeddings:
        return []
    
    query_embedding = get_embedding(query)
    if not query_embedding:
        return []
    
    query_embedding = np.array(query_embedding).reshape(1, -1)
    embeddings_array = np.array(embeddings)
    
    similarities = cosine_similarity(query_embedding, embeddings_array)[0]
    top_indices = np.argsort(similarities)[-top_k:][::-1]
    
    results = []
    for idx in top_indices:
        chunk = code_chunks[idx].copy()
        chunk['similarity'] = float(similarities[idx])
        results.append(chunk)
    
    return results

@app.post("/index")
async def index_codebase(request: IndexRequest):
    global code_chunks, embeddings
    
    code_chunks = []
    embeddings = []
    
    base_path = Path(request.path)
    
    if not base_path.exists():
        raise HTTPException(status_code=404, detail="Path not found")
    
    files_to_index = []
    for ext in request.extensions:
        files_to_index.extend(base_path.rglob(f"*{ext}"))
    
    excluded_dirs = {'node_modules', '.git', '__pycache__', 'venv', '.venv', 'dist', 'build'}
    
    for file_path in files_to_index:
        if any(excluded in file_path.parts for excluded in excluded_dirs):
            continue
        
        chunks = chunk_file(str(file_path), max_lines=50)
        
        for chunk in chunks:
            embedding = get_embedding(f"{chunk['file_path']}\n{chunk['content']}")
            if embedding:
                code_chunks.append(chunk)
                embeddings.append(embedding)
    
    return {
        "status": "success",
        "total_chunks": len(code_chunks),
        "files_indexed": len(files_to_index)
    }

@app.post("/query")
async def one_shot_query(request: QueryRequest):
    relevant_chunks = retrieve_relevant_chunks(request.question, request.top_k)
    
    if not relevant_chunks:
        return {
            "answer": "No code context found. Please index the codebase first.",
            "context": []
        }
    
    context_text = "\n\n".join([
        f"File: {chunk['file_path']} (lines {chunk['start_line']}-{chunk['end_line']})\n{chunk['content']}"
        for chunk in relevant_chunks
    ])
    
    system_prompt = """You are an expert coding assistant. Analyze the provided code context and answer the user's question with:
1. Clear explanations of what the code does
2. Identification of bugs or issues if present
3. Concrete fixes with exact code changes (show file names and line ranges)
4. Step-by-step debugging guidance when relevant

Be specific and actionable."""
    
    try:
        client = get_openai_client()
        response = client.chat.completions.create(
            model="gpt-4o-mini",
            messages=[
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": f"Code Context:\n{context_text}\n\nQuestion: {request.question}"}
            ],
            temperature=0.3
        )
        
        answer = response.choices[0].message.content
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"OpenAI API error: {str(e)}")
    
    return {
        "answer": answer,
        "context": relevant_chunks
    }

@app.post("/retrieve")
async def retrieve_context(request: QueryRequest):
    relevant_chunks = retrieve_relevant_chunks(request.question, request.top_k)
    
    return {
        "query": request.question,
        "chunks": relevant_chunks,
        "total_chunks": len(relevant_chunks)
    }

@app.post("/chat")
async def multi_turn_chat(request: ChatRequest):
    if request.session_id not in chat_sessions:
        chat_sessions[request.session_id] = []
    
    relevant_chunks = retrieve_relevant_chunks(request.message, request.top_k)
    
    context_text = "\n\n".join([
        f"File: {chunk['file_path']} (lines {chunk['start_line']}-{chunk['end_line']})\n{chunk['content']}"
        for chunk in relevant_chunks
    ]) if relevant_chunks else "No relevant code context found."
    
    system_prompt = """You are an expert debugging assistant. You help developers:
1. Understand error messages and tracebacks
2. Identify root causes of bugs
3. Suggest exact code fixes with file names and line numbers
4. Explain why errors occur and how to prevent them

Be concise, accurate, and always reference specific code locations."""
    
    messages = [{"role": "system", "content": system_prompt}]
    messages.extend(chat_sessions[request.session_id])
    messages.append({
        "role": "user",
        "content": f"Code Context:\n{context_text}\n\nUser Message: {request.message}"
    })
    
    try:
        client = get_openai_client()
        response = client.chat.completions.create(
            model="gpt-4o-mini",
            messages=messages,
            temperature=0.3
        )
        
        answer = response.choices[0].message.content
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"OpenAI API error: {str(e)}")
    
    chat_sessions[request.session_id].append({"role": "user", "content": request.message})
    chat_sessions[request.session_id].append({"role": "assistant", "content": answer})
    
    if len(chat_sessions[request.session_id]) > 20:
        chat_sessions[request.session_id] = chat_sessions[request.session_id][-20:]
    
    return {
        "answer": answer,
        "context": relevant_chunks,
        "session_id": request.session_id
    }

@app.get("/sessions/{session_id}/history")
async def get_session_history(session_id: str):
    if session_id not in chat_sessions:
        raise HTTPException(status_code=404, detail="Session not found")
    
    return {"history": chat_sessions[session_id]}

@app.delete("/sessions/{session_id}")
async def clear_session(session_id: str):
    if session_id in chat_sessions:
        del chat_sessions[session_id]
    return {"status": "success"}

@app.get("/stats")
async def get_stats():
    return {
        "indexed_chunks": len(code_chunks),
        "active_sessions": len(chat_sessions)
    }

app.mount("/static", StaticFiles(directory="static"), name="static")

@app.get("/")
async def serve_frontend():
    return FileResponse("static/index.html")

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=5000)
